# SwimmingPoolDataset > 2023-01-23 3:56pm
https://universe.roboflow.com/pratik-dhungana-pvv5d/swimmingpooldataset

Provided by a Roboflow user
License: CC BY 4.0

